# EduAll Grant Allocation in AnythingLLM: Setup Guide (no coding needed)

**Who this is for:** philanthropy students on **Windows or Mac**. You will only copy files, click in menus and paste text. No programming.

**What you will have at the end:** a chat assistant in AnythingLLM that helps you, the grant allocator, screen and compare the 500 EduAll applicants. It answers counts and lists exactly from the data, and for judgement calls (soft criteria) it asks a second, independent "reviewer" pass to critique the analysis. It supports your judgement; it never decides awards.

**Time needed:** about 20 minutes.

---

## What is in the package

Your teacher gives you a folder called **STUDENT_PACKAGE** (or a zip: unzip it first). Inside:

| Item | What it is | Where it goes |
|---|---|---|
| `A_copy_to_agent-skills` → folder `eduall-pool-query` | The "skill": the data tool (applicant table + the 500 applications + foundation documents) | AnythingLLM's `agent-skills` folder (Step 2) |
| `B_copy_to_agent-flows` → one `.json` file | The independent review procedure | AnythingLLM's `agent-flows` folder (Step 2) |
| `C_upload_these_documents` | 8 foundation and call documents | Uploaded into the workspace (Step 4) |
| `D_system_prompt_to_paste.txt` | The assistant's instructions | Pasted into workspace settings (Step 5) |

---

## Step 1. Install AnythingLLM and choose a model

1. Install **AnythingLLM Desktop** from anythingllm.com and open it once, so it creates its folders.
2. Make sure a language model is available: the built-in local model (for example **Qwen3-VL-4B**) is fine and keeps data on your computer. If your teacher gave you another model or key, use that.
3. **Close AnythingLLM completely** before Step 2 (Windows: also check the icon near the clock, right-click → Quit. Mac: AnythingLLM menu → Quit).

## Step 2. Copy the skill and the flow into AnythingLLM

### 2a. Open AnythingLLM's hidden "storage" folder

**On Windows**
1. Press the **Windows key + R**.
2. Type `%APPDATA%\anythingllm-desktop\storage` and press **Enter**. A folder window opens.

**On Mac**
1. Click on the desktop so **Finder** is active.
2. In the top menu choose **Go → Go to Folder…**
3. Paste `~/Library/Application Support/anythingllm-desktop/storage` and press **Return**.

### 2b. Find or create the `plugins` folders

Inside that storage folder you need this structure:

```
storage
└── plugins
    ├── agent-skills
    └── agent-flows
```

- If `plugins`, `agent-skills` or `agent-flows` do **not** exist, create them (right-click → New folder / Mac: File → New Folder). Use these **exact lowercase names**, with a hyphen.
- If they already exist and contain other things, leave those alone.

### 2c. Copy the skill folder
Copy the whole folder **`eduall-pool-query`** (from `A_copy_to_agent-skills`) **into** `agent-skills`. It is big (about 4 MB, 500+ files); let the copy finish. You should end up with:

```
agent-skills
└── eduall-pool-query
    ├── plugin.json
    ├── handler.js
    ├── core.js
    └── data
        ├── EduAll_500_Applications_Dataset.csv
        ├── applications   (500 files)
        └── foundation     (8 files)
```
Check that you did not create a folder inside a folder (`eduall-pool-query/eduall-pool-query`). `plugin.json` must be directly inside `eduall-pool-query`.

### 2d. Copy the flow file
Copy the single `.json` file from `B_copy_to_agent-flows` **into** `agent-flows`. Do not rename it.

## Step 3. Open AnythingLLM again

Start AnythingLLM. Go to **Settings** (spanner/gear icon, bottom left) → **Agent Skills**.

1. Under **custom / imported skills**, find **EduAll pool query** and switch it **on**.
2. Under **Agent Flows**, find **EduAll independent review** and switch it **on**.
3. Click **Save** if a button appears.

If you do not see them, close AnythingLLM completely and open it again. If still missing, see "If something goes wrong" below.

## Step 4. Create the workspace and upload documents

1. In the left bar click **New Workspace** (the **+** next to "Workspaces"). Name it **EduAll Grant Allocation**.
2. Click the **upload icon** (arrow pointing up) next to the workspace name.
3. Open the folder `C_upload_these_documents`, select **all 8 files** and drag them into the upload window.
4. Select the uploaded files in the list, click **Move to Workspace**, then **Save and Embed**. Wait until it finishes.

> Do **not** upload the 500 application files or the CSV here. The skill reads them directly and exactly.

## Step 5. Workspace settings

Click the **gear icon** next to your workspace name.

1. **Chat Settings**
   - **Chat mode**: choose **Automatic** (if you see "Agent" modes, choose the one that lets the assistant use tools without typing `@agent`).
   - **Chat model / provider**: choose your model (e.g. the local Qwen3-VL-4B).
   - **Prompt**: delete what is there and paste the **entire text** of `D_system_prompt_to_paste.txt` (open it with Notepad / TextEdit, select all, copy).
   - **Temperature**: set to **0.1** (so answers are consistent).
   - Click **Update workspace**.
2. **Agent Configuration**: set the **Workspace agent provider/model** to the same model. Click **Update**.

## Step 6. Test it

1. Open the workspace and click **New Thread** (a fresh thread is important).
2. Type: `Hello`.
3. The assistant should welcome you, check the data and **not** analyse anything yet. You may see a small line such as "EduAll pool query: describe", which means the skill works.
4. Try an exact question: *"How many applicants have residency permit C and a family household income of at least 6000 CHF?"* The correct answer is **20**.

## How to use it

- Give **one task at a time**. It asks clarifying questions until the rule is clear; answer them.
- **Hard screen** (clear rules, e.g. "exclude applicants without a valid permit"): you get a short report with counts and the remaining pool.
- **Soft judgement** (a comparison or trade-off, e.g. "how should low GPA weigh against high need?"): the assistant analyses, then runs the **independent review** automatically, and gives you a report with the analysis, the reviewer's critique and the questions left for you.
- You always decide. The assistant never awards money.
- Start a **new thread** if a thread shows errors; the assistant copies earlier errors.

## Good to know

- The reviewer is the **same model** as the analyst, run separately. It reduces but does not remove blind spots. Read its critique critically.
- Small local models are slower (soft requests can take 1-2 minutes) and their reviews can be repetitive. A stronger model gives better reviews, but your data would then be sent to that provider. Ask your teacher before using an online model with applicant data.
- Check the numbers that matter. Counts come from the data tool; the wording around them comes from the model.

## If something goes wrong

| Problem | What to do |
|---|---|
| The skill or flow is not listed in Settings → Agent Skills | Quit the app fully and reopen. Re-check the folder names (exact, lowercase) and that `plugin.json` is directly inside `eduall-pool-query`. |
| The assistant says it cannot reach the data tool | Same check; make sure the skill is switched **on** and you are in a **new thread**. |
| The assistant answers but never uses the tool | Check Chat mode is **Automatic**. As a fallback, start your message with `@agent`. |
| Soft request gives no review | Make sure the flow is switched **on**, and say explicitly: "get the independent review". |
| Error about quota / key | The online model's free limit is used up: wait, or switch to the local model. |
| Windows: cannot see AppData | Use the **Windows + R** method in Step 2a; AppData is hidden. |
