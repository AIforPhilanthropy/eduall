// EduAll pool query engine: exact, read-only analysis of the 500-applicant CSV and the individual application
// documents. No external dependencies, no database server, no state: every call is computed from the files in ./data.
'use strict';
const fs = require('fs');
const path = require('path');

const DATA = path.join(__dirname, 'data');
const CSV_FILE = path.join(DATA, 'EduAll_500_Applications_Dataset.csv');
const APP_DIR = path.join(DATA, 'applications');
const ID_RE = /^STU\d{6}$/;
const MAX_ROWS = 200;

let cache = null;

function parseCsv(text) {
  const rows = [];
  let row = [], field = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else q = false; } else field += c;
    } else if (c === '"') q = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c !== '\r') field += c;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.length > 1 || r[0] !== '');
}

function load() {
  const mtime = fs.statSync(CSV_FILE).mtimeMs;
  if (cache && cache.mtime === mtime) return cache;
  const [header, ...body] = parseCsv(fs.readFileSync(CSV_FILE, 'utf8'));
  const cols = header.map((h) => h.trim());
  const numeric = cols.map((_, j) => body.every((r) => r[j] === '' || r[j] === undefined || !isNaN(Number(r[j]))));
  const rows = body.map((r) => {
    const o = {};
    cols.forEach((c, j) => {
      const v = r[j];
      o[c] = v === '' || v === undefined ? null : numeric[j] ? Number(v) : v.trim();
    });
    return o;
  });
  cache = { mtime, cols, numeric: Object.fromEntries(cols.map((c, j) => [c, numeric[j]])), rows, byId: new Map(rows.map((r) => [r.student_id, r])) };
  return cache;
}

// ---------- arithmetic for derived columns (no eval) ----------
function parseExpr(src, known) {
  const toks = src.match(/\s*([A-Za-z_][A-Za-z0-9_]*|\d+\.?\d*|[-+*/(),])/g);
  if (!toks || toks.join('').replace(/\s/g, '') !== src.replace(/\s/g, '')) throw new Error(`cannot parse expression "${src}"`);
  const t = toks.map((x) => x.trim());
  let p = 0;
  const peek = () => t[p];
  const next = () => t[p++];
  function primary() {
    const x = next();
    if (x === undefined) throw new Error(`unexpected end of expression "${src}"`);
    if (x === '(') { const e = add(); if (next() !== ')') throw new Error('missing )'); return e; }
    if (x === '-') { const e = primary(); return (r) => { const v = e(r); return v === null ? null : -v; }; }
    if (/^\d/.test(x)) { const n = Number(x); return () => n; }
    if (peek() === '(') {
      next(); const args = [];
      if (peek() !== ')') { args.push(add()); while (peek() === ',') { next(); args.push(add()); } }
      if (next() !== ')') throw new Error('missing )');
      const fn = { min: Math.min, max: Math.max, abs: Math.abs }[x.toLowerCase()];
      if (!fn) throw new Error(`unknown function ${x} (use min, max, abs)`);
      return (r) => { const v = args.map((a) => a(r)); return v.some((y) => y === null) ? null : fn(...v); };
    }
    if (!known(x)) throw new Error(`unknown field "${x}" in expression "${src}"`);
    return (r) => r[x];
  }
  function mul() {
    let l = primary();
    while (peek() === '*' || peek() === '/') {
      const op = next(), rgt = primary(), L = l;
      l = (r) => { const a = L(r), b = rgt(r); if (a === null || b === null) return null; return op === '*' ? a * b : b === 0 ? null : a / b; };
    }
    return l;
  }
  function add() {
    let l = mul();
    while (peek() === '+' || peek() === '-') {
      const op = next(), rgt = mul(), L = l;
      l = (r) => { const a = L(r), b = rgt(r); if (a === null || b === null) return null; return op === '+' ? a + b : a - b; };
    }
    return l;
  }
  const f = add();
  if (p !== t.length) throw new Error(`cannot parse expression "${src}"`);
  return f;
}

// ---------- filters ----------
function leaf(node, known, numericOf) {
  const { field, op } = node;
  if (!known(field)) throw new Error(`unknown field "${field}"`);
  const get = (r) => r[field];
  const isNum = numericOf(field);
  const cmpVal = (r) => (node.value_field !== undefined ? (known(node.value_field) ? r[node.value_field] : (() => { throw new Error(`unknown field "${node.value_field}"`); })()) : node.value);
  const norm = (v) => (typeof v === 'string' ? v.toLowerCase() : v);
  const num = (v) => (isNum && typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)) ? Number(v) : v);
  switch (op) {
    case 'is_null': return (r) => get(r) === null || get(r) === undefined;
    case 'not_null': return (r) => get(r) !== null && get(r) !== undefined;
    case '=': case '==': return (r) => { const a = get(r), b = num(cmpVal(r)); return a !== null && b !== null && norm(a) === norm(b); };
    case '!=': return (r) => { const a = get(r), b = num(cmpVal(r)); return a !== null && b !== null && norm(a) !== norm(b); };
    case '>': case '>=': case '<': case '<=': return (r) => {
      const a = get(r), b = num(cmpVal(r));
      if (a === null || b === null || a === undefined || b === undefined) return false;
      return op === '>' ? a > b : op === '>=' ? a >= b : op === '<' ? a < b : a <= b;
    };
    case 'between': {
      if (!Array.isArray(node.value) || node.value.length !== 2) throw new Error('between needs value:[low, high]');
      const [lo, hi] = node.value.map(num);
      return (r) => { const a = get(r); return a !== null && a >= lo && a <= hi; };
    }
    case 'in': case 'not_in': {
      if (!Array.isArray(node.value)) throw new Error(`${op} needs value as an array`);
      const set = new Set(node.value.map((v) => norm(num(v))));
      return (r) => { const a = get(r); if (a === null) return false; return op === 'in' ? set.has(norm(a)) : !set.has(norm(a)); };
    }
    case 'contains': return (r) => get(r) !== null && String(get(r)).toLowerCase().includes(String(node.value).toLowerCase());
    case 'starts_with': return (r) => get(r) !== null && String(get(r)).toLowerCase().startsWith(String(node.value).toLowerCase());
    default: throw new Error(`unknown operator "${op}" (use = != > >= < <= between in not_in contains starts_with is_null not_null)`);
  }
}
function compile(node, known, numericOf) {
  if (!node || typeof node !== 'object') throw new Error('where must be an object');
  if (node.and) { const fs_ = node.and.map((n) => compile(n, known, numericOf)); return (r) => fs_.every((f) => f(r)); }
  if (node.or) { const fs_ = node.or.map((n) => compile(n, known, numericOf)); return (r) => fs_.some((f) => f(r)); }
  if (node.not) { const f = compile(node.not, known, numericOf); return (r) => !f(r); }
  return leaf(node, known, numericOf);
}

// ---------- query ----------
function parseSpec(spec) {
  if (spec === undefined || spec === null || spec === '') return {};
  if (typeof spec === 'object') return spec;
  try { return JSON.parse(spec); } catch (e) {
    // Small models often drop closing brackets or leave trailing commas: repair those only.
    const stack = []; let inStr = false, esc = false;
    for (const ch of String(spec)) {
      if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
      if (ch === '"') inStr = true;
      else if (ch === '{') stack.push('}');
      else if (ch === '[') stack.push(']');
      else if (ch === '}' || ch === ']') stack.pop();
    }
    const fixed = String(spec).replace(/,\s*$/, '') + (inStr ? '"' : '') + stack.reverse().join('');
    try { return JSON.parse(fixed.replace(/,(\s*[}\]])/g, '$1')); } catch (e2) {
      throw new Error(`spec is not valid JSON (${e.message}). Send a complete JSON object string, e.g. {"where":{"field":"residency_permit","op":"=","value":"C"},"ids":true}`);
    }
  }
}

function prepare(spec) {
  const d = load();
  const derived = {};
  const names = new Set(d.cols);
  for (const dv of spec.derive || []) {
    if (!dv.as || !dv.expr) throw new Error('each derive item needs "as" and "expr"');
    derived[dv.as] = parseExpr(dv.expr, (x) => names.has(x));
    names.add(dv.as);
  }
  const known = (f) => names.has(f);
  const numericOf = (f) => (derived[f] ? true : !!d.numeric[f]);
  let rows = d.rows.map((r) => {
    if (!Object.keys(derived).length) return r;
    const o = { ...r };
    for (const k of Object.keys(derived)) o[k] = derived[k](o);
    return o;
  });
  const total = rows.length;
  if (spec.restrict_ids) {
    const ids = Array.isArray(spec.restrict_ids) ? spec.restrict_ids : String(spec.restrict_ids).split(/[\s,;]+/);
    const set = new Set(ids.filter(Boolean).map((x) => x.toUpperCase()));
    const bad = [...set].filter((x) => !d.byId.has(x));
    if (bad.length) throw new Error(`restrict_ids contains unknown ids: ${bad.slice(0, 10).join(', ')}`);
    rows = rows.filter((r) => set.has(r.student_id));
  }
  const scope = rows.length;
  if (spec.where) { const f = compile(spec.where, known, numericOf); rows = rows.filter(f); }
  return { d, rows, total, scope, known };
}

const fmt = (v) => (v === null || v === undefined ? '' : typeof v === 'number' ? String(Math.round(v * 100) / 100) : String(v).replace(/\|/g, '/'));
function table(cols, rows) {
  return [`| ${cols.join(' | ')} |`, `|${cols.map(() => '---').join('|')}|`, ...rows.map((r) => `| ${cols.map((c) => fmt(r[c])).join(' | ')} |`)].join('\n');
}
function aggregate(fn, vals) {
  const v = vals.filter((x) => x !== null && x !== undefined && typeof x === 'number');
  if (fn === 'count') return vals.length;
  if (fn === 'count_nonnull') return vals.filter((x) => x !== null && x !== undefined).length;
  if (!v.length) return null;
  const s = [...v].sort((a, b) => a - b);
  switch (fn) {
    case 'sum': return v.reduce((a, b) => a + b, 0);
    case 'avg': return v.reduce((a, b) => a + b, 0) / v.length;
    case 'min': return s[0];
    case 'max': return s[s.length - 1];
    case 'median': return s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
    default: throw new Error(`unknown aggregate "${fn}" (use count, count_nonnull, sum, avg, min, max, median)`);
  }
}

function query(spec) {
  const { rows, total, scope, known } = prepare(spec);
  const out = [`Dataset: ${total} applicants${scope !== total ? `; scope restricted to ${scope}` : ''}. Matching rows: **${rows.length}**.`];
  const chk = (f) => { if (!known(f)) throw new Error(`unknown field "${f}"`); return f; };
  if (spec.group_by || spec.aggregates) {
    const gb = (spec.group_by || []).map(chk);
    const aggs = (spec.aggregates && spec.aggregates.length ? spec.aggregates : [{ fn: 'count' }]).map((a) => {
      if (a.fn !== 'count' && a.field) chk(a.field);
      return { ...a, as: a.as || (a.field ? `${a.fn}_${a.field}` : a.fn) };
    });
    const groups = new Map();
    for (const r of rows) { const k = JSON.stringify(gb.map((g) => r[g])); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(r); }
    let res = [...groups.entries()].map(([k, rs]) => {
      const o = {}; JSON.parse(k).forEach((v, i) => { o[gb[i]] = v; });
      aggs.forEach((a) => { o[a.as] = aggregate(a.fn, a.field ? rs.map((r) => r[a.field]) : rs); });
      return o;
    });
    const ob = spec.order_by && spec.order_by[0] ? spec.order_by : [{ field: aggs[0].as, dir: 'desc' }];
    res = sortRows(res, ob);
    out.push(table([...gb, ...aggs.map((a) => a.as)], res.slice(0, MAX_ROWS)));
    if (res.length > MAX_ROWS) out.push(`(showing first ${MAX_ROWS} of ${res.length} groups)`);
  } else if (spec.select) {
    const sel = spec.select.map(chk);
    const sorted = spec.order_by ? sortRows(rows, spec.order_by) : rows;
    const lim = Math.min(Number(spec.limit) || 25, MAX_ROWS);
    out.push(table(sel, sorted.slice(0, lim)));
    if (rows.length > lim) out.push(`(showing ${lim} of ${rows.length} rows; raise "limit" up to ${MAX_ROWS} or narrow the filter)`);
  }
  if (spec.ids) {
    const ids = (spec.order_by ? sortRows(rows, spec.order_by) : rows).map((r) => r.student_id);
    out.push(`student_ids (${ids.length}): ${ids.join(', ')}`);
  }
  return out.join('\n\n');
}
function sortRows(rows, ob) {
  return [...rows].sort((a, b) => {
    for (const { field, dir } of ob) {
      const x = a[field], y = b[field];
      if (x === y) continue;
      if (x === null || x === undefined) return 1;
      if (y === null || y === undefined) return -1;
      const c = x < y ? -1 : 1;
      return String(dir).toLowerCase() === 'desc' ? -c : c;
    }
    return 0;
  });
}

// ---------- describe ----------
function describe() {
  const d = load();
  const lines = [`${d.rows.length} applicants (one row each, key student_id), ${d.cols.length} columns.`, '', `DATA FOLDER (pass exactly this text as data_dir to the review flow): ${DATA}`, '', '| column | type | missing | values / range |', '|---|---|---|---|'];
  for (const c of d.cols) {
    const vals = d.rows.map((r) => r[c]);
    const miss = vals.filter((v) => v === null).length;
    let info;
    if (c === 'student_id' || c === 'application_date') info = `${new Set(vals).size} distinct`;
    else if (d.numeric[c]) {
      const n = vals.filter((v) => v !== null);
      const u = [...new Set(n)];
      info = u.length <= 3 ? `values ${u.sort((a, b) => a - b).join(', ')}` : `min ${Math.min(...n)}, max ${Math.max(...n)}, mean ${fmt(n.reduce((a, b) => a + b, 0) / n.length)}`;
    } else {
      const counts = {}; vals.forEach((v) => { counts[v] = (counts[v] || 0) + 1; });
      const e = Object.entries(counts).sort((a, b) => b[1] - a[1]);
      info = e.length <= 25 ? e.map(([k, n]) => `${k} (${n})`).join('; ') : `${e.length} distinct`;
    }
    lines.push(`| ${c} | ${d.numeric[c] ? 'number' : 'text'} | ${miss} | ${info.replace(/\|/g, '/')} |`);
  }
  return lines.join('\n');
}

// ---------- applicant / documents ----------
function idList(v) {
  const ids = (Array.isArray(v) ? v : String(v || '').split(/[\s,;]+/)).filter(Boolean).map((x) => String(x).toUpperCase());
  const d = load();
  for (const i of ids) if (!ID_RE.test(i) || !d.byId.has(i)) throw new Error(`unknown student id "${i}"`);
  return ids;
}
function appText(id) { return fs.readFileSync(path.join(APP_DIR, `${id}_application.md`), 'utf8'); }

function applicant(spec) {
  const ids = idList(spec.ids);
  if (!ids.length) throw new Error('give "ids" (e.g. ["STU000001"])');
  const d = load();
  return ids.slice(0, 20).map((id) => `### ${id}\n` + d.cols.map((c) => `- ${c}: ${fmt(d.byId.get(id)[c])}`).join('\n')).join('\n\n');
}

function readApplication(spec) {
  const ids = idList(spec.ids);
  if (!ids.length) throw new Error('give "ids" (e.g. ["STU000001"])');
  const secs = spec.sections ? [].concat(spec.sections).map((s) => String(s).toLowerCase()) : null;
  return ids.slice(0, 5).map((id) => {
    let t = appText(id);
    if (secs) {
      const parts = t.split(/\n(?=## )/);
      t = parts.filter((p) => secs.some((s) => p.split('\n')[0].toLowerCase().includes(s))).join('\n\n') || '(no section matched; sections are: ' + parts.map((p) => p.split('\n')[0]).join(' | ') + ')';
    }
    return `===== ${id} =====\n${t}`;
  }).join('\n\n');
}

function searchText(spec) {
  if (!spec.pattern) throw new Error('give "pattern" (a word or regular expression, case-insensitive)');
  let re;
  try { re = new RegExp(spec.pattern, 'i'); } catch (e) { throw new Error(`invalid pattern: ${e.message}`); }
  const { rows, total, scope } = prepare(spec);
  const hits = [];
  for (const r of rows) {
    let t = appText(r.student_id);
    const cut = t.indexOf('## Section 4');
    t = cut >= 0 ? t.slice(cut) : t; // statements, CV and declared circumstances only: skip the form tables
    const m = re.exec(t);
    if (m) hits.push({ id: r.student_id, snip: t.slice(Math.max(0, m.index - 80), m.index + m[0].length + 80).replace(/\s+/g, ' ') });
  }
  const lim = Math.min(Number(spec.limit) || 10, 50);
  const out = [`Searched the narrative sections (financial need statement, personal statement, CV, declared circumstances) of ${rows.length} applications${rows.length !== total ? ` (of ${total})` : ''} for /${spec.pattern}/i. Applications with a match: **${hits.length}**.`];
  out.push(`student_ids: ${hits.map((h) => h.id).join(', ') || '(none)'}`);
  if (hits.length) out.push(hits.slice(0, lim).map((h) => `- ${h.id}: …${h.snip}…`).join('\n'));
  if (hits.length > lim) out.push(`(snippets for the first ${lim} only)`);
  return out.join('\n\n');
}

// ---------- CSV vs. application document ----------
const num = (s) => (s === undefined || s === null ? null : Number(String(s).replace(/[',]/g, '')));
function parseDoc(t) {
  const g = (re) => { const m = re.exec(t); return m ? m[1].trim() : null; };
  const chf = (label) => num(g(new RegExp(`${label}[^\\n]*?CHF\\s*([\\d',]+)`)));
  const row = (label) => num(g(new RegExp(`\\|\\s*${label}[^|]*\\|\\s*CHF\\s*([\\d',]+)`)));
  const ticked = (label) => new RegExp(`^- ✓ ${label}`, 'm').test(t) ? 1 : 0;
  const perm = g(/Residency Permit:\*\*\s*(.+)/);
  const sch = g(/Other Scholarships\/Support:\*\*\s*(.+)/);
  const rent = row('Rent');
  const util = row('Utilities');
  return {
    age: num(g(/Age:\*\*\s*(\d+)/)), gender: g(/Gender:\*\*\s*(.+)/), country_origin: g(/Country of Origin:\*\*\s*(.+)/),
    geographic_region: g(/Geographic Region:\*\*\s*(.+)/), dependent_children: num(g(/Dependent Children:\*\*\s*(\d+)/)),
    residency_permit: perm ? (/^Pending/i.test(perm) ? 'Pending' : (/Type\s+([A-Z])/.exec(perm) || [])[1] || perm) : null,
    university: (g(/University:\*\*\s*(.+)/) || '').replace(/\s*\([^)]*\)\s*$/, '') || null, study_level: g(/Study Level:\*\*\s*(.+)/),
    field_of_study: g(/Field of Study:\*\*\s*(.+)/), study_mode: g(/Study Mode:\*\*\s*(.+)/), planned_study_mode_2027: g(/Planned Study Mode in 2027\/28:\*\*\s*(.+)/),
    tuition_fees_per_year_chf: chf('Tuition and Semester Fees:\\*\\*'), semesters_in_program: num(g(/Semesters Completed:\*\*\s*(\d+)/)),
    gpa: num(g(/GPA:\*\*\s*([\d.]+)/)), average_grade: num(g(/Average Grade:\*\*\s*([\d.]+)/)), courses_completed: num(g(/Courses Completed:\*\*\s*(\d+)/)),
    publications: num(g(/Publications:\*\*\s*(\d+)/)), academic_standing: g(/Academic Standing:\*\*\s*(.+)/),
    family_income_chf: row('Family support'), personal_income_chf: row('Personal income'), monthly_expenses_chf: row('\\*\\*Total monthly expenses'),
    housing_cost_chf: rent === null ? null : rent + (util || 0),
    family_household_income_chf: chf('Combined monthly income of supporting family members'), expected_personal_income_2027_chf: chf('Expected personal income in 2027/28'),
    savings_chf: chf('Savings:\\*\\*'), financial_need_chf: chf('Current Monthly Financial Need'),
    has_external_scholarship: sch === null ? null : /^Yes/i.test(sch) ? 1 : 0, external_scholarship_amount_chf: sch === null ? null : /^Yes/i.test(sch) ? num((/CHF\s*([\d',]+)/.exec(sch) || [])[1]) : 0,
    risk_first_generation: ticked('First-generation'), risk_refugee_asylum: ticked('Refugee'), risk_disability: ticked('Disability'),
    risk_housing_insecurity: ticked('Housing insecurity'), risk_family_emergency: ticked('Family emergency'), risk_language_barrier: ticked('Language barrier'),
    risk_parent_student: ticked('Student parent'), risk_undocumented_status: ticked('Undocumented'),
    resilience_volunteer_experience: ticked('Volunteer'), resilience_work_experience: ticked('Work experience'), resilience_leadership_role: ticked('Leadership'),
    resilience_community_engagement: ticked('Community engagement'), resilience_overcame_adversity: ticked('Overcame'),
  };
}
function crosscheck(spec) {
  const d = load();
  const ids = spec.ids && (Array.isArray(spec.ids) ? spec.ids.length : String(spec.ids).trim()) ? idList(spec.ids) : prepare(spec).rows.map((r) => r.student_id);
  const diffs = [];
  for (const id of ids) {
    const doc = parseDoc(appText(id)), csv = d.byId.get(id);
    for (const [k, v] of Object.entries(doc)) {
      if (!(k in csv) || v === null) continue;
      const a = csv[k];
      const same = typeof a === 'number' ? Math.abs(a - v) < 0.011 : String(a).toLowerCase() === String(v).toLowerCase() || (k === 'university' && String(a).toLowerCase().startsWith(String(v).toLowerCase().slice(0, 12)));
      if (!same) diffs.push({ id, field: k, csv: a, document: v });
    }
  }
  const lim = Math.min(Number(spec.limit) || 60, 300);
  const bad = new Set(diffs.map((x) => x.id));
  const out = [`Compared the structured CSV row with the application form of ${ids.length} applicant(s) on ${Object.keys(parseDoc(appText(ids[0] || 'STU000001'))).length} fields. Applicants with at least one difference: **${bad.size}**; differing fields: **${diffs.length}**.`];
  if (diffs.length) out.push(table(['id', 'field', 'csv', 'document'], diffs.slice(0, lim)));
  if (diffs.length > lim) out.push(`(showing ${lim} of ${diffs.length})`);
  out.push('Note: the narrative statements can also contradict the numbers; use read_application to read them.');
  return out.join('\n\n');
}

function run(params) {
  const action = String(params.action || 'describe').toLowerCase();
  const spec = parseSpec(params.spec);
  switch (action) {
    case 'describe': return describe();
    case 'query': return query(spec);
    case 'applicant': return applicant(spec);
    case 'read_application': return readApplication(spec);
    case 'search_text': return searchText(spec);
    case 'crosscheck': return crosscheck(spec);
    default: throw new Error(`unknown action "${action}". Use describe, query, applicant, read_application, search_text or crosscheck.`);
  }
}

module.exports = { run, load, parseDoc };
