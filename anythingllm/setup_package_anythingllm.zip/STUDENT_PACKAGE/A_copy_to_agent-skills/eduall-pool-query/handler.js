// Reload the engine on every call so edits take effect without restarting AnythingLLM.
module.exports.runtime = {
  handler: async function (params) {
    try {
      try { delete require.cache[require.resolve('./core.js')]; } catch (e) {}
      const core = require('./core.js');
      this.introspect(`EduAll pool query: ${String((params && params.action) || 'describe')}`);
      return core.run(params || {});
    } catch (e) {
      return `EduAll pool query error: ${e.message}`;
    }
  },
};
