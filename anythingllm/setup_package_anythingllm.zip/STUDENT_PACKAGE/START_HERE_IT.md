# EduAll Grant Allocation in AnythingLLM: guida all'installazione (senza programmare)

**Per chi è:** studenti di filantropia con computer **Windows o Mac**. Dovrete solo copiare file, cliccare nei menu e incollare un testo. Nessuna programmazione.

**Cosa avrete alla fine:** un assistente in chat in AnythingLLM che vi aiuta, come responsabile dell'assegnazione dei contributi, a selezionare e confrontare i 500 candidati EduAll. Conteggi ed elenchi sono esatti perché vengono dai dati; per i giudizi discrezionali (criteri "soft") l'assistente fa eseguire una seconda verifica indipendente, il "revisore", che critica l'analisi. L'assistente supporta il vostro giudizio e non decide mai chi riceve il contributo.

**Tempo necessario:** circa 20 minuti.

---

## Cosa c'è nel pacchetto

L'insegnante vi consegna una cartella **STUDENT_PACKAGE** (oppure uno zip: decomprimetelo prima). Contiene:

| Elemento | Cos'è | Dove va |
|---|---|---|
| `A_copy_to_agent-skills` → cartella `eduall-pool-query` | La "skill": lo strumento dati (tabella dei candidati, le 500 candidature, i documenti della fondazione) | Cartella `agent-skills` di AnythingLLM (Passo 2) |
| `B_copy_to_agent-flows` → un file `.json` | La procedura di revisione indipendente | Cartella `agent-flows` di AnythingLLM (Passo 2) |
| `C_upload_these_documents` | 8 documenti della fondazione e del bando | Caricati nello spazio di lavoro (Passo 4) |
| `D_system_prompt_to_paste.txt` | Le istruzioni dell'assistente | Incollate nelle impostazioni dello spazio di lavoro (Passo 5) |

---

## Passo 1. Installare AnythingLLM e scegliere un modello

1. Installate **AnythingLLM Desktop** da anythingllm.com e apritelo una volta, così crea le sue cartelle.
2. Verificate di avere un modello linguistico: va bene il modello locale integrato (ad esempio **Qwen3-VL-4B**), che tiene i dati sul vostro computer. Se l'insegnante vi ha dato un altro modello o una chiave, usate quello.
3. **Chiudete completamente AnythingLLM** prima del Passo 2 (Windows: controllate anche l'icona vicino all'orologio, tasto destro → Esci. Mac: menu AnythingLLM → Esci).

## Passo 2. Copiare skill e flow dentro AnythingLLM

### 2a. Aprire la cartella nascosta "storage" di AnythingLLM

**Su Windows**
1. Premete **tasto Windows + R**.
2. Scrivete `%APPDATA%\anythingllm-desktop\storage` e premete **Invio**. Si apre una finestra con la cartella.

**Su Mac**
1. Cliccate sulla scrivania in modo che sia attivo il **Finder**.
2. Nel menu in alto scegliete **Vai → Vai alla cartella…**
3. Incollate `~/Library/Application Support/anythingllm-desktop/storage` e premete **Invio**.

### 2b. Trovare o creare le cartelle `plugins`

Dentro la cartella storage serve questa struttura:

```
storage
└── plugins
    ├── agent-skills
    └── agent-flows
```

- Se `plugins`, `agent-skills` o `agent-flows` **non esistono**, createle (tasto destro → Nuova cartella / Mac: File → Nuova cartella). Usate **esattamente questi nomi in minuscolo**, con il trattino.
- Se esistono già e contengono altro, non toccate quel contenuto.

### 2c. Copiare la cartella della skill
Copiate l'intera cartella **`eduall-pool-query`** (da `A_copy_to_agent-skills`) **dentro** `agent-skills`. Pesa circa 4 MB e contiene più di 500 file: aspettate la fine della copia. Il risultato deve essere:

```
agent-skills
└── eduall-pool-query
    ├── plugin.json
    ├── handler.js
    ├── core.js
    └── data
        ├── EduAll_500_Applications_Dataset.csv
        ├── applications   (500 file)
        └── foundation     (8 file)
```
Controllate di non aver creato una cartella dentro una cartella (`eduall-pool-query/eduall-pool-query`). `plugin.json` deve stare direttamente dentro `eduall-pool-query`.

### 2d. Copiare il file del flow
Copiate l'unico file `.json` da `B_copy_to_agent-flows` **dentro** `agent-flows`. Non rinominatelo.

## Passo 3. Riaprire AnythingLLM

Avviate AnythingLLM. Andate in **Impostazioni** (icona chiave inglese/ingranaggio, in basso a sinistra) → **Agent Skills**.

1. Tra le **skill personalizzate / importate** trovate **EduAll pool query** e **attivatela**.
2. Tra gli **Agent Flows** trovate **EduAll independent review** e **attivatelo**.
3. Cliccate **Salva** se compare il pulsante.

Se non le vedete, chiudete completamente AnythingLLM e riapritelo. Se ancora mancano, vedere "Se qualcosa non funziona" qui sotto.

## Passo 4. Creare lo spazio di lavoro e caricare i documenti

1. Nella barra a sinistra cliccate **Nuovo spazio di lavoro** (il **+** accanto a "Workspaces"). Chiamatelo **EduAll Grant Allocation**.
2. Cliccate sull'**icona di caricamento** (freccia verso l'alto) accanto al nome dello spazio di lavoro.
3. Aprite la cartella `C_upload_these_documents`, selezionate **tutti e 8 i file** e trascinateli nella finestra di caricamento.
4. Selezionate i file caricati nell'elenco, cliccate **Move to Workspace** (Sposta nello spazio di lavoro), poi **Save and Embed** (Salva e incorpora). Attendete la fine.

> **Non** caricate qui le 500 candidature né il CSV. La skill li legge direttamente e in modo esatto.

## Passo 5. Impostazioni dello spazio di lavoro

Cliccate sull'**icona dell'ingranaggio** accanto al nome dello spazio di lavoro.

1. **Chat Settings** (impostazioni chat)
   - **Chat mode**: scegliete **Automatic** (se vedete modalità "Agent", scegliete quella che permette all'assistente di usare gli strumenti senza scrivere `@agent`).
   - **Modello / provider della chat**: scegliete il vostro modello (ad esempio il Qwen3-VL-4B locale).
   - **Prompt**: cancellate il testo presente e incollate **tutto il testo** di `D_system_prompt_to_paste.txt` (apritelo con Blocco note / TextEdit, selezionate tutto, copiate).
   - **Temperature**: impostate **0,1** (risposte più coerenti).
   - Cliccate **Update workspace**.
2. **Agent Configuration**: impostate **provider/modello dell'agente** sullo stesso modello. Cliccate **Update**.

## Passo 6. Provare

1. Aprite lo spazio di lavoro e cliccate **New Thread** (un thread nuovo è importante).
2. Scrivete: `Ciao`.
3. L'assistente deve darvi il benvenuto, controllare i dati e **non** analizzare ancora nulla. Potreste vedere una piccola riga come "EduAll pool query: describe": significa che la skill funziona.
4. Provate una domanda esatta: *"Quanti candidati hanno permesso di soggiorno C e un reddito familiare di almeno 6000 CHF?"* La risposta corretta è **20**.

## Come usarlo

- Date **un compito alla volta**. L'assistente fa domande di chiarimento finché la regola è chiara: rispondete.
- **Selezione rigida** (regole chiare, ad es. "escludi chi non ha un permesso valido"): ricevete un breve rapporto con conteggi e candidati rimasti.
- **Giudizio soft** (un confronto o un compromesso, ad es. "quanto deve pesare un GPA basso rispetto a un bisogno alto?"): l'assistente analizza, poi esegue automaticamente la **revisione indipendente** e vi consegna un rapporto con l'analisi, la critica del revisore e le domande che restano a voi.
- Decidete sempre voi. L'assistente non assegna mai denaro.
- Aprite un **nuovo thread** se un thread mostra errori: l'assistente imita gli errori precedenti.

## Da sapere

- Il revisore è **lo stesso modello** dell'analista, eseguito separatamente. Riduce i punti ciechi ma non li elimina. Leggete la sua critica con occhio critico.
- I modelli locali piccoli sono più lenti (una richiesta soft può richiedere 1-2 minuti) e le loro revisioni possono essere ripetitive. Un modello più potente dà revisioni migliori, ma i dati verrebbero inviati a quel fornitore. Chiedete all'insegnante prima di usare un modello online con i dati dei candidati.
- Controllate i numeri importanti. I conteggi vengono dallo strumento dati; le parole intorno ai numeri vengono dal modello.

## Se qualcosa non funziona

| Problema | Cosa fare |
|---|---|
| Skill o flow non compaiono in Impostazioni → Agent Skills | Chiudete del tutto l'app e riapritela. Ricontrollate i nomi delle cartelle (esatti, minuscoli) e che `plugin.json` sia direttamente dentro `eduall-pool-query`. |
| L'assistente dice di non raggiungere lo strumento dati | Stesso controllo; verificate che la skill sia **attiva** e di essere in un **nuovo thread**. |
| L'assistente risponde ma non usa mai lo strumento | Controllate che Chat mode sia **Automatic**. In alternativa iniziate il messaggio con `@agent`. |
| La richiesta soft non produce revisione | Verificate che il flow sia **attivo** e scrivete esplicitamente: "esegui la revisione indipendente". |
| Errore di quota / chiave | Il limite gratuito del modello online è esaurito: aspettate o passate al modello locale. |
| Windows: non vedo AppData | Usate il metodo **Windows + R** del Passo 2a; AppData è nascosta. |
